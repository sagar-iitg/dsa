#Python Program to generate a student's roll number based on his year of admission, programme , discipline and serial number

import sys
import string
def RollNumberGenerator(prog_info):
    input_array=[]
    input_array=prog_info.split(',')

    #Exrating year,programme,discipline,serial number, external information from the user input
    year=int(input_array[0])
    programme=str(input_array[1])
    discipline=str(input_array[2])
    serial_number=str(input_array[3])
    external_student=str(input_array[4])

    #Return Error if year of admission is not between 1994-2019
    if(year<1994 or year>2019):
        return "Invalid Year of Admission. Must be between 1994-2019"

    #Validate if the programme exists for the input programme code
    if str(programme) in programmeCode.keys():
            #Validate if the Discipline exists for the input discipline code
            if str(discipline) in disciplineCode.keys():
                #Validate if a student is enrolled for M.Tech+Ph.D only in CSE or not
                if(programme=='M.Tech+Ph.D' and discipline!='Computer Science and Engineering'):
                    return "M.Tech+Ph.D is available only for CSE"

                #Validate if a student is enrolled for MS(Engg)+Ph.D only in EEE or not
                if(programme=='MS(Engg)+Ph.D' and discipline!='Electronics and Communication Engineering'):
                    return "MS(Engg)+Ph.D is available only for EEE"

                #Validate if a student is enrolled for MS(R) only in Energy or not
                if(programme=='MS(R)' and discipline!='Energy'):
                    return "MS(R) is only availble for Energy"

                #Validate if a student is enrolled for MA only in Development STudies or not
                if(discipline=='Development Studies' and programme!='MA'):
                    return discipline+" is  availble only for MA"

		#Validate if a student is enrolled for MA only in Development STudies or not
                if(programme=='MA' and discipline!='Development Studies'):
                    return discipline+" is  not availble for MA"
		

                if((discipline=='Chemical Science and Technology' or discipline=='Engineering Physics' ) and programme!='B.Tech'):
                    return str(discipline)+ " is  availble only for B.Tech"

                if((discipline=='Chemistry' or discipline=='Physics') and programme!='M.Sc'):
                    return str(discipline)+ " is  availble only for M.Sc"


                #Return the roll number if year, programme and discipline is valid based on the input
                roll_no=(str(year)[2:])+programmeCode[programme]+disciplineCode[discipline]+serial_number

                #Append an X before the roll number if the student is an external student studying at IITG
                if(external_student=='Yes'):
                    return "X"+str(roll_no)

                #Return the generated Roll number if the student is an internal student of IITG
                return (str(roll_no))
            else:
                return "Discipline does not exists"
    else:
        return "Programme does not exists"

    return "Programme or Discipline does not exists "

disciplineCode={'Computer Science and Engineering':'01','Electronics and Communication Engineering':'02','Mechanical Energy':'03','Civil Energy':'04','Design':'05','Biotechnology':'06','Chemical Enginnering':'07','Electronics and Electrical Engineering':'08','Physics':'21','Engineering Physics':'21','Chemistry':'22','Chemical Science and Technology':'22','Mathematics and Computing':'23','Humanities and Social Sciences':'41','Development Studies':'41','Energy':'51','Environment':'52','Nano Technology':'53','Centre of Rural Technology':'54','Centre For Linguistics Science and Technology':'55','Data Science':'61'}

programmeCode={'B.Tech':'01','B.Des':'02','M.Sc':'21','MA':'22','M.Tech':'41','M.Des':'42','MS(R)':'43','Ph.D':'61','M.Tech+Ph.D':'62','MS(Engg)+Ph.D':'63'}


#Main Declaration
if __name__=='__main__':

    f_Write=open("GeneratedOutputForQuestion3.txt","w+")
    f_Write.write("Year".ljust(10)+ " Programme ".ljust(20)+" Discipline ".ljust(50)+" Serial".ljust(10)+" External? ".ljust(5)+" Roll Number\n")
    #Run the program untill the user input is <0 0 0 0>
    while(1):
        student_info=input()

        #Terminate the program if user input is <0 0 0 0>
        if(student_info=='0 0 0 0'):
            f_Write.write("\n"+student_info+" : End Of Program \n")
            print("Please open GeneratedOutputForQuestion3.txt for the output!")
            sys.exit()

        input_array=student_info.split(',')

        #Write the output to the Output file
        f_Write.write(input_array[0].ljust(10) +"\t"+ input_array[1].ljust(20) + input_array[2].ljust(50) +input_array[3].ljust(10) +input_array[4].ljust(5)+RollNumberGenerator(student_info)+"\n")

    f_Write.close()

