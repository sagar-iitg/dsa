#Python Program to generate all possible combination of a student's academic program enrollment
import random
def RandomProgrammeInput():

    f_Write=open("GeneratedInputForQuestion3.txt","w+")
    #Predefined set of programmes available
    programme=['B.Tech','B.Des','M.Sc','MA','M.Tech','M.Des','MS(R)','Ph.D','M.Tech+Ph.D','MS(Engg)+Ph.D','B.Pharm','B.Sc']

    #Predefined set of discipline available
    discipline=['Computer Science and Engineering','Electronics and Communication Engineering','Mechanical Energy','Civil Energy','Design','Biotechnology','Chemical Enginnering','Electronics and Electrical Engineering','Physics','Engineering Physics','Chemistry','Chemical Science and Technology','Mathematics and Computing','Humanities and Social Sciences','Development Studies','Energy','Environment','Nano Technology','Centre of Rural Technology','Centre For Linguistics Science and Technology','Data Science','Aeronautics']


    #Generate random integer for generation of test cases
    test_cases=random.sample(range(1,2500),450)
    for i in test_cases:

        for j in programme:
            for k in discipline:
                #Random year of enrollment
                year=str(f'{random.randrange(1992, 2020):004}')

                f_Write.write (year+","+j+","+ k+ "," + str(f'{random.randrange(1, 10**3):003}')+","+random.choice(['Yes','No'])+"\n")

    #Program Terminating Condition
    f_Write.write ('0 0 0 0\n')
    print("Input Cases Generated. Please open the GeneratedInputForQuestion3.txt file for the input cases!")
RandomProgrammeInput()

