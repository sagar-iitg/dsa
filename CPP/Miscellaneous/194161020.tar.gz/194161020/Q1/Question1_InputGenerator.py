#Python program to generate random inputs for Memory Conversion from One Unit to Another
import random

def RandomMemorySize():

    f= open("GeneratedInputForQuestion1.txt","w+")

    #Set of defined memory units
    units = ('EB','PB','TB','GB','MB','KB','B','bits')

    #Set of letters for generating invalid memory size
    alphanumeric=['a','%','e','i','/','q','o','@','#',' ','.','*','!']

    #Generate a random number of integers for memory size
    test_memory_size=random.sample(range(-5000,5000),random.randint(1,60))
    count=0;
    for i in test_memory_size:

        for j in range(len(units)):
            for k in range(len(units)):
                count+=1
                #Generate a Alphanumeric memory size on random
                if(count%(random.randint(1,49))==0):
                    f.write(''.join(random.choice(alphanumeric)for a in range(random.randint(0,10)))+" " +units[j]+" "+units[k]+"\n")
                #Generate a blank memory size on random
                if(count%(random.randint(1,205))==0):
                    f.write("   "+" " +units[j]+" "+units[k]+"\n")

                #Concatenate a random From Unit and a random To Unit with the memory size for the input
                f.write(str(random.randint(-5000,5000))+" " +units[j]+" "+units[k]+"\n")

    #Generate a program terminating input case
    f.write ("0 00 00\n")
    print("Input Cases Generated. Please open the GeneratedInputForQuestion1.txt file for the input cases!")
    f.close()

#Run the function to generate input cases
RandomMemorySize()

