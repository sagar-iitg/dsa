
#Python Program to convert one memory unit into another
import sys
def memory_conversion(memory_size):
    
    #Splitting the user input on space for getting the memory size and conversion units
    input_array=memory_size.split(' ')

    #Validating if the Memory Size input is a valid number or not
    if(isNumber(input_array[0])==False):
        return "Memory Size not recognised. It should be numeric!"

    #mem stores the memory size to convert
    mem=float(input_array[0])

    #Input is considered valid only if it has 3 arguments namely: memory size, conversion unit(FROM) and conversion unit(TO)
    if(len(input_array)==3):

    #Input is considered valid if memory size is positive
        if(float(input_array[0])>=0):

            unit_to_convert_from=input_array[1].strip()
            unit_to_convert_to=input_array[2].strip()

            #Conversion unit input validation(whether input units are defined)
            if(any(unit_to_convert_from in i for i in possible_memory_units) & any(unit_to_convert_to in i for i in possible_memory_units)):

                #Counting the jump between 'From' and 'To' Unit
                unit_jump=possible_memory_units.index(unit_to_convert_to)-possible_memory_units.index(unit_to_convert_from)

                #If Jump is positive, conversion happens from higher Unit to Lower Unit
                if(unit_jump>0):
                    for i in range(1,abs(unit_jump)+1):
                        mem*=1024
                    if(unit_to_convert_to=='bits'):
                        mem=(mem/1024)*8

                #If Jump is negative, conversion happens from lower Unit to Higher Unit
                if(unit_jump<0):
                    for i in range(1,abs(unit_jump)+1):
                        mem/=1024
                    if(unit_to_convert_from=='bits'):
                        mem=(mem/8)*1024

                #Return the computed memory size along with the 'TO' Unit
                return str(mem)+" " +input_array[2]

            #If Conversion units are undefined, then display an error message
            else:

                return "Invalid Conversion Units provided. Could not convert!"

        #If memory size is negative, display an error message
        else:

            return "Memory Size cannot be negative! Could not convert!"

    #If the user input doesnot have 3 arguments(memory size, From Unit, To Unit) then display an error message
    else:

        return "Invalid Input. Could not convert!"




    return "Memory not recognised"

#Possible memory units are defined below. Any other input will result into exception
possible_memory_units=('EB','PB','TB','GB','MB','KB','B','bits')

#Function to check if a value(string) is Number or Not
def isNumber(value):
    try:
        float(value)
    except ValueError:
        return False
    return True


#Main Declaration
if __name__ == "__main__":

    #Write the generated output in the respective output file
    f_Write=open("GeneratedOutputForQuestion1.txt","w+")

    #Run the program until user inputs <0 0 0>
    while(1):

        #input Format: '<Memory Size> <From Unit> <To Unit>'
        memory_input=input()

        #Exit the program if input is <0 0 0>
        if(memory_input=='0 00 00'):
            f_Write.write("\n"+memory_input.ljust(15)+" : End Of Program \n")
            print("Please open GeneratedOutputForQuestion1.txt for the output!")
            sys.exit()

        #Print the converted memory Size
        f_Write.write("\n"+memory_input.ljust(15) +": " +memory_conversion(memory_input))

    f_Write.close()

