#Python Program to Convert Hexadecimal Number into Decimal Number
import sys
def HexaToDecimalFraction(hexInput):

    input_array=[]
    if (hexInput==''):
        return "Cannot perform Empty Conversion"
    #Validating whether it has fractional part or not(by checking the presence of dot(.) in input)
    if(any('.' in i for i in hexInput)):
        input_array=hexInput.split(('.'))
    else:
        input_array=[hexInput]

    #Validating if the user input has more than one dot(.) in the input. In that case it will be considered a wrong input
    if(len(input_array)>2):
        return "Invalid Input"


    #If the user input has fractional part. Convert integer and fractional part separately and add both of them
    elif(len(input_array)==2):

        DecimalPart=0
        fractionalPart=0

        #Count the number of digits after dot(.)
        fractionalLength=len(input_array[1])
        power=1
        for i in range(1,fractionalLength+1):
            power=power*16

        #If Integer part is not blank(for eg : .12C), convert the integer(hexadecimal) part into decimal
        if(input_array[0]!=''):
            DecimalPart=int(input_array[0],16)
        #If Fractional part is not blank(for eg : 12C. ), convert the fractional(hexadecimal) part into decimal
        if(input_array[1]!=''):
            fractionalPart=(int(input_array[1],16))/(power)

        #Add both the integer value and the fractional value
        return(str(DecimalPart+fractionalPart))

    #If the input is just an integer, simply convert into decimal value
    elif(len(input_array)==1):
        return (str(int(input_array[0],16)))



#Main Declaration
if __name__=="__main__" :

    f_Write=open("GeneratedOutputForQuestion4.txt","w+")

    #File Header
    f_Write.write("  Hexadecimal".ljust(20)+" \t Decimal \n\n")

    #Run the program until the user input is <0.0>
    while(1):
        hexInput=input()

        #Terminate the program if user input is <0.0>
        if(hexInput=='0.0'):
            f_Write.write("\n"+hexInput+" : End Of Program \n")
            print("Please open GeneratedOutputForQuestion4.txt for the output!")
            sys.exit()

        f_Write.write(hexInput.ljust(20)+" : ".ljust(5)+HexaToDecimalFraction(hexInput)+"\n")

    f_Write.close()


