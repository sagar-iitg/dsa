#Python Program to generate a random length input for Hexadecimal Number
import random

def randomHexNumber(length):

    #File Pointer to write randomly generated hexadecimal numbers to the input file
    f_Write=open("GeneratedInputForQuestion4.txt","w+")

    #Predefined set of literals for Hexadecimal Number*
    hexDigits = ['a','A','B','b','C','c','d','D','E','e','F','f','.','0','1','2','3','4','5']

    #Generate random Number of test Cases
    test_cases=[i for i in range(random.randint(0,10000))]
    for i in test_cases:
        f_Write.write( ''.join(random.choice(hexDigits) for i in range(random.randint(10,length)))+"\n")

    #Program terminating Conditon
    f_Write.write ('0.0\n')

    f_Write.close()

    print("Input Cases Generated. Please open the GeneratedInputForQuestion4.txt file for the input cases!")

#Generate Hexadecimal Inputs of random length(between 10 and 20)
randomHexNumber(random.randint(10,20))

