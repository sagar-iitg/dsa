#Python Program to generate Random Roll Numbers
import random
def RandomProgrammeInputRollGenerator():

    #File Pointer to open a file for writing the random roll numbers generated
    f_Write=open("GeneratedInputForQuestion2.txt","w+")

    year=[i for i in range(1990,2020)]
    programmeCode=['01','02','21','22','41','42','42','43','61','62','63','65','00']
    disciplineCode=['01','02','03','04','05','06','07','08','21','22','23','41','51','52','53','54','55','61','00']
    #Generate a random number of integers for the total number of Roll Numbers to be generated
    test_cases=[i for i in (range(5000,random.randint(5000,random.randint(5000,10000))))]


    for i in test_cases:

        #Generate random year,programme,discipline and serial Number
        random_year=str(random.choice(year))[2:]
        random_programme=random.choice(programmeCode)
        random_discipline=random.choice(disciplineCode)
        random_serialNumber=str(f'{random.randrange(1, 10**3):003}')
        f_Write.write(random_year+random_programme+random_discipline+random_serialNumber+"\n")

    #Generate the program terminating case
    f_Write.write ('0 0 0 0\n')

    f_Write.close()
    print("Input Cases Generated. Please open the GeneratedInputForQuestion2.txt file for the input cases!")

#Function Call to generate the random number of Roll Numbers
RandomProgrammeInputRollGenerator()
