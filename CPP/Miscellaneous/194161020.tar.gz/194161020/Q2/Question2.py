#Python Program to count the number of students in any programme(B.Tech, M.Tech, etc) based on the roll number given as input
import sys
import string
def CountProgrammeFrequency(prog_info):

        #Extracting the year of enrollment
        enrolled_year=prog_info[:2]

        #Return Invalid roll number if the code for year is beyond 1993 and after 2020
        if(20<=int(enrolled_year )<=93):
            return -1
        #Extracting the Programme Code from the user input
        enrolled_programme=prog_info[2:4]

        #Extracting the Discipline Code from the user input
        enrolled_discipline=prog_info[4:6]

        #Validate if the Programme exists for the input programme code
        if str(enrolled_programme) in programmeCode.keys():
            #Validate if the Discipline exists for the input discipline code
            if str(enrolled_discipline) in disciplineCode.keys():

                #Return the programme name if year, programme and discipline is valid based on the input roll number
                return str(programmeCode.get(enrolled_programme))

        #Return -1 in any other case
        return -1

#Predefined set of Programmes and its code
programmeCode={'01':'B.Tech','02':'B.Des','21':'M.Sc','22':'MA','41':'M.Tech','42':'M.Des','43':'MS(R)','61':'Ph.D','62':'M.Tech+Ph.D','63':'MS(Engg)+Ph.D'}
disciplineCode={'01':'Computer Science and Engineering','02':'Electronics and Communication Engineering','03':'Mechanical Energy','04':'Civil Energy','05':'Design','06':'Biotechnology','07':'Chemical Enginnering','08':'Electronics and Electrical Engineering','21':'Physics','22':'Chemistry','23':'Mathematics and Computing','41':'Development Studies','51':'Energy','52':'Environment','53':'Nano Technology','54':'Centre of Rural Technology','55':'Centre For Linguistics Science and Technology','61':'Data Science'}




#Main Declaration
if __name__=='__main__':

        f_Write=open("GeneratedOutputForQuestion2.txt","w+")
        f_Write.write("Total Count of students is at the bottom:\n\n")
        programme=0
        #Initial Program Count set to 0
        programmeCount={'B.Tech':0,'B.Des':0,'M.Sc':0,'MA':0,'M.Tech':0,'M.Des':0,'MS(R)':0,'Ph.D':0,'M.Tech+Ph.D':0,'MS(Engg)+Ph.D':0}

        #Run the Program untill the user input is <0 0 0 0>
        while(1):

            #User input is the Roll Number
            roll_input=input()

            #Display the Programme Count and terminate the program if the user input is <0 0 0 0>
            if(roll_input=='0 0 0 0'):
                f_Write.write("\nTotal Count of students in every program :\n")
                for key,val in programmeCount.items():
                    f_Write.write(key.ljust(13)+ "=>".ljust(7)+ str(val)+"\n")
                print("Please open GeneratedOutputForQuestion2.txt for the output!")
                sys.exit()
            
            #Get the Programme Name based on the roll number given as input
            programme=CountProgrammeFrequency(roll_input)

            #Increment the programme count if valid programme is returned as an output
            if(programme==-1):
                f_Write.write(roll_input.ljust(10)+" :".ljust(5)+" Invalid Roll Number.Either year,programme or discipline is invalid.\n")
            else:
                f_Write.write(roll_input.ljust(10)+" :".ljust(5)+" Roll Number recorded for "+programme+"\n")
                programmeCount[programme]+=1;

        f_Write.close()

